# Resume-Screening-System
# Resume Screening System

## Introduction

A Resume Screening System is an intelligent application that automates the process of analyzing and ranking resumes based on job requirements. Instead of manually reviewing hundreds of resumes, the system uses Machine Learning and Natural Language Processing (NLP) techniques to identify the most suitable candidates. This reduces recruitment time, improves accuracy, and helps organizations shortlist qualified applicants efficiently.

## Objective

The primary objective of the Resume Screening System is to:

* Automate the resume screening process.
* Match candidate skills with job descriptions.
* Calculate an ATS (Applicant Tracking System) score.
* Rank resumes based on relevance.
* Reduce human effort and hiring time.

## Features

* Upload resumes in PDF format.
* Extract text from resumes.
* Clean and preprocess resume text.
* Compare resumes with job descriptions.
* Calculate ATS score and similarity score.
* Rank candidates based on matching percentage.
* Display confidence score and resume ranking.
* User-friendly dashboard for recruiters.



# 🛠️ Technologies & Libraries Used

The Resume Screening System is developed using Python and several powerful libraries for machine learning, natural language processing, document parsing, visualization, and web application development.

| Technology / Library | Description                                                                                                                            |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------- |
| **Streamlit**        | Provides an interactive web interface for uploading resumes, entering job descriptions, and viewing ATS scores and candidate rankings. |
| **Pandas**           | Used for data loading, preprocessing, and manipulation of resume and job description data.                                             |
| **NumPy**            | Supports efficient numerical computations and array operations required during data processing.                                        |
| **Scikit-learn**     | Implements TF-IDF Vectorization, Cosine Similarity, and machine learning models for resume matching and candidate ranking.             |
| **Joblib**           | Saves and loads trained machine learning models for faster deployment.                                                                 |
| **NLTK**             | Performs Natural Language Processing (NLP) tasks such as tokenization, stop-word removal, stemming, and text cleaning.                 |
| **PyMuPDF (fitz)**   | Extracts text from PDF resumes with high accuracy.                                                                                     |
| **python-docx**      | Reads and extracts text from Microsoft Word (.docx) resumes.                                                                           |
| **Pytesseract**      | Uses Optical Character Recognition (OCR) to extract text from scanned resumes and image-based documents.                               |
| **Pillow (PIL)**     | Processes and enhances images before OCR extraction.                                                                                   |
| **pdf2image**        | Converts PDF pages into images, enabling OCR for scanned PDF resumes.                                                                  |
| **Matplotlib**       | Generates graphs and charts for resume analysis and ATS score visualization.                                                           |
| **Seaborn**          | Creates attractive statistical visualizations for recruitment insights.                                                                |
| **Plotly**           | Builds interactive charts and dashboards for resume comparison and candidate analysis.                                                 |
| **ReportLab**        | Generates downloadable PDF reports containing ATS scores, resume rankings, and screening summaries.                                    |

## Key Features

* 📄 Supports PDF and DOCX resume formats.
* 🤖 Machine Learning–based resume screening.
* 🔍 TF-IDF and Cosine Similarity for resume-job matching.
* 📊 ATS score calculation and resume ranking.
* 📈 Interactive dashboard with visual analytics.
* 📑 Automatic PDF report generation.
* 🌐 Easy-to-use Streamlit web application.


## Working of the System

1. The recruiter uploads one or more resumes.
2. The system extracts text from each PDF.
3. The extracted text is cleaned by removing punctuation, stop words, and unnecessary characters.
4. The job description is processed in the same way.
5. TF-IDF converts the resume and job description into numerical vectors.
6. Cosine Similarity measures how closely each resume matches the job description.
7. The system calculates an ATS score and ranks the resumes.
8. Results are displayed on the dashboard with scores and rankings.

## Machine Learning Approach

The system uses **TF-IDF (Term Frequency–Inverse Document Frequency)** to represent textual information as numerical vectors. **Cosine Similarity** is then used to measure the similarity between the resume and the job description. Higher similarity indicates a better match.

## Advantages

* Saves recruiters significant time.
* Reduces manual screening effort.
* Provides objective and consistent evaluation.
* Improves candidate shortlisting.
* Easy to use and scalable.

## Applications

* Human Resource (HR) departments.
* Recruitment agencies.
* Campus placement cells.
* Corporate hiring portals.
* Online job portals.

## Future Enhancements

* Support for multiple resume formats (DOCX, TXT).
* AI-based skill extraction.
* Experience and education analysis.
* Resume recommendation system.
* Integration with job portals and ATS platforms.
* Semantic matching using transformer models such as BERT.

## Conclusion

The Resume Screening System streamlines the recruitment process by automatically evaluating resumes against job requirements. Using NLP and Machine Learning techniques such as TF-IDF and Cosine Similarity, the system provides accurate resume ranking and ATS scoring. It enables recruiters to identify the most suitable candidates quickly, making the hiring process faster, more efficient, and more reliable.
